// ============================================================
// functions/index.js
// نظام الإشعارات الذكية (Push) + الجدولة الزمنية (Cron) - منصة سفرة
// ------------------------------------------------------------
// 1) onNewOrderNotifyRestaurant      → إشعار فوري لصاحب المطعم عند وصول طلب جديد
// 2) onOrderStatusChangedNotifyCustomer → إشعار الزبون عند تغيّر حالة طلبه
// 3) checkScheduledOrders (Cron)     → يفحص كل دقيقة الطلبات المسبقة التي حان
//                                       موعدها، يرسل تنبيه Push للزبون وصاحب
//                                       المطعم، ويحدّث حالة الطلب تلقائياً
// ============================================================

const { onSchedule } = require("firebase-functions/v2/scheduler");
const { onDocumentCreated, onDocumentUpdated } = require("firebase-functions/v2/firestore");
const { setGlobalOptions } = require("firebase-functions/v2");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();
const messaging = admin.messaging();

// المنطقة الافتراضية لكل الدوال (عدّلها لو مشروعك بمنطقة مختلفة)
setGlobalOptions({ region: "us-central1", maxInstances: 10 });

// ============================================================
// دوال مساعدة
// ============================================================

/**
 * يرسل إشعار Push لمستخدم واحد اعتماداً على fcmToken المخزّن في وثيقته
 * ضمن users/{uid}. لو ما في توكن (المستخدم ما فعّل الإشعارات) يتجاهل بصمت.
 */
async function sendPushToUser(uid, notification, data = {}) {
  if (!uid) return;
  try {
    const userDoc = await db.collection("users").doc(uid).get();
    const token = userDoc.exists ? userDoc.data().fcmToken : null;
    if (!token) return;

    await messaging.send({
      token,
      notification,
      // كل قيم data لازم تكون نصوص (String) حسب متطلبات FCM
      data: Object.fromEntries(Object.entries(data).map(([k, v]) => [k, String(v)])),
      webpush: {
        fcmOptions: { link: data.link || "/" },
        notification: { icon: "/logo.png" }
      }
    });
  } catch (err) {
    console.error(`تعذر إرسال إشعار للمستخدم ${uid}:`, err.message);
    // لو التوكن ملغى/منتهي، نمسحه عشان ما نحاول عليه مرة ثانية
    if (err.code === "messaging/registration-token-not-registered") {
      await db.collection("users").doc(uid)
        .update({ fcmToken: admin.firestore.FieldValue.delete() })
        .catch(() => {});
    }
  }
}

/** يجيب uid صاحب المطعم اعتماداً على ownerEmail المخزّن بوثيقة المطعم */
async function getRestaurantOwnerUid(restaurantId) {
  if (!restaurantId) return null;
  try {
    const restDoc = await db.collection("restaurants").doc(restaurantId).get();
    if (!restDoc.exists) return null;
    const ownerEmail = restDoc.data().ownerEmail;
    if (!ownerEmail) return null;
    const userRecord = await admin.auth().getUserByEmail(ownerEmail).catch(() => null);
    return userRecord ? userRecord.uid : null;
  } catch (err) {
    console.error("تعذر جلب صاحب المطعم:", err.message);
    return null;
  }
}

function formatDate(ts) {
  try {
    return ts?.toDate ? ts.toDate().toLocaleString("ar-EG") : "غير محدد";
  } catch {
    return "غير محدد";
  }
}

// ============================================================
// 1) إشعار فوري لصاحب المطعم عند إنشاء طلب جديد (فوري أو مسبق)
// ============================================================
exports.onNewOrderNotifyRestaurant = onDocumentCreated("orders/{orderId}", async (event) => {
  const order = event.data?.data();
  if (!order) return;

  const ownerUid = await getRestaurantOwnerUid(order.restaurantId);
  if (!ownerUid) return;

  const title = order.isScheduled ? "📅 طلب مسبق جديد" : "🔔 طلب جديد";
  const body = order.isScheduled
    ? `طلب مسبق بقيمة ${order.total ?? "-"} د.أ - موعد التجهيز: ${formatDate(order.scheduledFor)}`
    : `وصلك طلب جديد بقيمة ${order.total ?? "-"} د.أ - جهّزه بأقرب وقت ممكن`;

  await sendPushToUser(
    ownerUid,
    { title, body },
    { orderId: event.params.orderId, link: "/adman.html" }
  );
});

// ============================================================
// 2) إشعار الزبون عند تغيّر حالة طلبه (تم الشحن، قيد المعالجة، ...)
// ============================================================
exports.onOrderStatusChangedNotifyCustomer = onDocumentUpdated("orders/{orderId}", async (event) => {
  const before = event.data?.before?.data();
  const after = event.data?.after?.data();
  if (!before || !after) return;
  if (before.status === after.status) return; // لا يوجد تغيير فعلي بالحالة

  const customerUid = after.customerId || after.userId;
  if (!customerUid) return;

  await sendPushToUser(
    customerUid,
    {
      title: "سفرة - تحديث حالة طلبك",
      body: `طلبك رقم #${event.params.orderId.substring(0, 6)} أصبح: ${after.status}`
    },
    { orderId: event.params.orderId, link: "/orders.html" }
  );
});

// ============================================================
// 3) الجدولة الزمنية (Cron): فحص الطلبات المسبقة كل دقيقة
//    - يعمل من طرف الخادم، فلا يعتمد على بقاء المتصفح مفتوحاً
//    - عند حلول الموعد: يرسل Push للزبون وصاحب المطعم، ويحدّث الحالة تلقائياً
// ============================================================
exports.checkScheduledOrders = onSchedule("every 1 minutes", async () => {
  const now = admin.firestore.Timestamp.now();

  const snapshot = await db.collection("orders")
    .where("isScheduled", "==", true)
    .where("scheduleNotified", "==", false)
    .where("scheduledFor", "<=", now)
    .get();

  if (snapshot.empty) {
    return; // ما في طلبات مسبقة حان موعدها الآن
  }

  const batch = db.batch();
  const pushJobs = [];

  snapshot.forEach((docSnap) => {
    const order = docSnap.data();
    const orderId = docSnap.id;

    batch.update(docSnap.ref, {
      status: "قيد المعالجة",
      scheduleNotified: true,
      scheduleNotifiedAt: admin.firestore.FieldValue.serverTimestamp()
    });

    // تنبيه الزبون
    const customerUid = order.customerId || order.userId;
    if (customerUid) {
      pushJobs.push(sendPushToUser(
        customerUid,
        {
          title: "⏰ حان موعد طلبك المسبق",
          body: `طلبك رقم #${orderId.substring(0, 6)} قيد التجهيز الآن`
        },
        { orderId, link: "/orders.html" }
      ));
    }

    // تنبيه صاحب المطعم
    pushJobs.push(
      getRestaurantOwnerUid(order.restaurantId).then((ownerUid) => {
        if (!ownerUid) return;
        return sendPushToUser(
          ownerUid,
          {
            title: "⏰ ابدأ تجهيز طلب مسبق الآن",
            body: `الطلب رقم #${orderId.substring(0, 6)} حان موعد تجهيزه`
          },
          { orderId, link: "/adman.html" }
        );
      })
    );
  });

  await Promise.all([batch.commit(), ...pushJobs]);
  console.log(`تمت معالجة وتنبيه ${snapshot.size} طلب/طلبات مسبقة حان موعدها.`);
});

// ============================================================
// 4) إشعار صاحب المطعم فور تغيّر حالة طلب اشتراكه
//    (تفعيل مباشر / توليد كود / رفض) — يشتغل تلقائياً من السيرفر
//    بمجرد ما الأدمن يعدّل حالة الطلب من لوحة الإدارة.
// ============================================================
exports.onSubscriptionStatusChangedNotifyOwner = onDocumentUpdated("subscriptions/{subId}", async (event) => {
  const before = event.data?.before?.data();
  const after = event.data?.after?.data();
  if (!before || !after) return;
  if (before.status === after.status) return; // لا يوجد تغيير فعلي بالحالة
  if (!after.ownerUid) return;

  let title = "سفرة - تحديث حالة الاشتراك";
  let body = `اشتراك مطعم "${after.restaurantName || ''}" أصبح: ${after.status}`;

  if (after.status === "نشط") {
    title = "🎉 تم تفعيل اشتراكك!";
    body = `مبروك، صار مطعمك "${after.restaurantName || ''}" مفعّل على منصة سفرة.`;
  } else if (after.status === "بانتظار كود التفعيل") {
    title = "🔑 اشتراكك جاهز للتفعيل";
    body = "راجعنا طلبك، رح نتواصل معك بكود التفعيل. أدخله بصفحة الاشتراك لتفعيل حسابك فورًا.";
  } else if (after.status === "مرفوض") {
    title = "❌ تم رفض طلب اشتراكك";
    body = after.adminNote ? `السبب: ${after.adminNote}` : "تواصل مع فريق سفرة لمعرفة التفاصيل.";
  }

  await sendPushToUser(
    after.ownerUid,
    { title, body },
    { subscriptionId: event.params.subId, link: "/اشتراك.html" }
  );
});
